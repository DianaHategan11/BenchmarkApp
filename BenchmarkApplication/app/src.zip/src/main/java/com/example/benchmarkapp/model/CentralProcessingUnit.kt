package com.example.benchmarkapp.model

data class CentralProcessingUnit (val score : Float)