package com.example.benchmarkapp.model

data class GraphicalProcessingUnit (val score : Float)