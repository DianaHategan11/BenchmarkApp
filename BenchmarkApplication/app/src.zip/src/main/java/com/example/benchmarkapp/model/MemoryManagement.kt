package com.example.benchmarkapp.model

data class MemoryManagement(val score: Float)